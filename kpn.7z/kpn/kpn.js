const gra = () => {
   let wynikGracza = 0;
   let wynikKomputer = 0;
   let ruchy = 0;

   const graj = () => {
       const kamienBtn = document.querySelector('.kamien');
       const papierBtn = document.querySelector('.papier');
       const nozyceBtn = document.querySelector('.nozyce');
       const opcjegracza = [kamienBtn,papierBtn,nozyceBtn];
       const opcjekomp = ['kamien','papier','nozyce']


       opcjegracza.forEach(option => {
           option.addEventListener('click',function(){

               const pozruchy = document.querySelector('.pozruchy');
               ruchy++;
               pozruchy.innerText = `ruchy: ${10-ruchy}`;


               const wyborNumber = Math.floor(Math.random()*3);
               const wyborKomp = opcjekomp[wyborNumber];


               wygrany(this.innerText,wyborKomp)


               if(ruchy ==  10){
                   koniecGry(opcjegracza,pozruchy);
               }
           })
       })

   }

   const wygrany = (Gracz,Komputer) => {
       const wynik = document.querySelector('.wynik');
       const kto = document.querySelector('.kto')
       const tabelaGracz = document.querySelector('.licznik');
       const tabelaKomp = document.querySelector('.licznikKomp');
       Gracz = Gracz.toLowerCase();
       Komputer = Komputer.toLowerCase();
       if(Gracz === Komputer){
         kto.textContent = 'Remis'    
       }
       else if(Gracz == 'kamien'){
           if(Komputer == 'papier'){
               kto.textContent = 'Komputer Wygral (Wybral papier)';
               wynikKomputer++;
               tabelaKomp.textContent = wynikKomputer;
           }else{
               kto.textContent = 'Gracz Wygral (komputer wybrał nożyce)'
               wynikGracza++;
               tabelaGracz.textContent = wynikGracza;
           }
       }
       else if(Gracz == 'nozyce'){
           if(Komputer == 'kamien'){
               kto.textContent = 'Komputer Wygral (Wybrał kamien)';
               wynikKomputer++;
               tabelaKomp.textContent = wynikKomputer;
           }else{
               kto.textContent = 'Gracz Wygral (komputer wybrał papier) ';
               wynikGracza++;
               tabelaGracz.textContent = wynikGracza;
           }
       }
       else if(Gracz == 'papier'){
           if(Komputer == 'nozyce'){
               kto.textContent = 'Komputer Wygral (Wybrał nozyce)';
               wynikKomputer++;
               tabelaKomp.textContent = wynikKomputer;
           }else{
               kto.textContent = 'Gracz Wygral (komputer wybrał kamień)';
               wynikGracza++;
               tabelaGracz.textContent = wynikGracza;
           }
       }
   }

   const koniecGry = (opcjegracza,pozruchy) => {
       const wybierzRucha = document.querySelector('.ruch');
       const wynik = document.querySelector('.kto');
       const resetBtn = document.querySelector('.reset');

       opcjegracza.forEach(option => {
           option.style.display = 'none';
       })
   
       wybierzRucha.innerText = 'Koniec gry!'
       pozruchy.style.display = 'none';

       if(wynikGracza > wynikKomputer){
           wynik.innerText = 'Gracz wygral'
       }
       else if(wynikGracza < wynikKomputer){
           wynik.innerText = 'Przegrales';
       }
       else{
           wynik.innerText = 'Remis';
       }
       resetBtn.innerText = 'Restart';
       resetBtn.style.display = 'flex'
       resetBtn.addEventListener('click',() => {
           window.location.reload();
       })
   }
   graj();
}
gra();
